#include "card.h"

const char *SuitNames[] = {"Spades", "Hearts", "Clubs", "Diamonds"};

const char *SpotNames[] = {"Two", "Three", "Four", "Five", "Six", 
                           "Seven", "Eight", "Nine", "Ten", "Jack", 
                           "Queen", "King", "Ace"};
