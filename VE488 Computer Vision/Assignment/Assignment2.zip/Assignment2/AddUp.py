def AddUp(nums, target):
    """
    Input:
    - nums: List[int]
    - target: Int
    
    Returns:
    - List[int]
    """
