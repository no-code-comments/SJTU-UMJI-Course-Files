import numpy as np
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
from matplotlib.image import imsave

def DCT_transform(img):
    """
    Inputs:
    - img: An 2-D numpy array of shape (H,W)

    Returns:
    - img_dct: the dct transformation result, a 2-D numpy array of shape (H, W)

    Hint: implement the dct transformation basis matrix
    """
    H,W = img.shape

    return img_dct

def iDCT_transform(img_dct):
    """
    Inputs:
    - img_dct: An 2-D numpy array of shape (H,W)

    Returns:
    - img_recover: recoverd image, a 2-D numpy array of shape (H, W)

    Hint: use the same dct transformation basis matrix but do the reverse operation
    """
    H,W = img_dct.shape

    return img_recover


def main():
    #############################################
    ############ Global compression #############
    #############################################
    image = mpimg.imread('lena.jpg')
    image = image.astype('float')
    H,W = image.shape

    image_dct = DCT_transform(image)

    ### Visualize the log map of dct (image_dct_log) here ###
    image_dct_log = np.log(abs(image_dct))

    ### Compress the dct result here by preserving 1/4 data (H/2,W/2) in image_dct and set others to zero here ###
    image_dct_compress = 

    image_recover = iDCT_transform(image_dct)
    image_compress_recover = iDCT_transform(image_dct_compress)


    #############################################
    ########## Blockwise compression ############
    #############################################
    image = mpimg.imread('lena.jpg')
    image = image.astype('float')

    patches_num_h = int(H/8)
    patches_num_w = int(W/8)

    img_recover = np.zeros(image.shape)
    image_recover_compress = np.zeros(image.shape)
    image_dct_log = np.zeros(image.shape)

    for i in range(patches_num_h):
        for j in range(patches_num_w):
            ### divide the image into 8x8 pixel image patches here ###
            patch = 
            patch_dct = DCT_transform(patch)

            patch_dct_log = np.log(abs(patch_dct))

            ### Compress the dct result here by preserving 1/4 data (H/2,W/2) in image_dct and set others to zero here
            patch_dct_compress = 

            patch_recover = iDCT_transform(patch_dct)
            patch_compress_recover = iDCT_transform(patch_dct_compress)

            ### put patches together here
            img_recover[?] = patch_recover
            image_recover_compress[?] = patch_compress_recover
            image_dct_log[?] = patch_dct_log



if __name__ == "__main__":
    main()


 
