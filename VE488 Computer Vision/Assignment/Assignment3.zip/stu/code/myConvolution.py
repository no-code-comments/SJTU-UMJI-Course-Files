from typing import Tuple, Union
import numpy as np


def myConv2D(
    img:np.ndarray, kernel:np.ndarray, 
    stride:Union[int, Tuple[int,int]] = 1, 
    padding:Union[int, Tuple[int, int]]=0) -> np.ndarray:
    """Convolve two 2-dimensional arrays.

    Args:
        img (np.ndarray): A grayscale image.
        kernel (np.ndarray): A odd-sized 2d convolution kernel.
        stride (int or tuple, optional): The parameter to control the movement of the kernel. 
            An integer input k will be automatically converted to a tuple (k, k). Defaults to 1.
        padding (int or tuple, optional): The parameter to control the amount of padding to the image. 
            An integer input k will be automatically converted to a tuple (k, k). Defaults to 0.

    Returns (np.ndarray): The processed image.
    """
    # TODO: check the datatype of stride and padding
    # hint: isinstance()
    
    # TODO: define the size of the output and initialize

    # TODO: add padding to the image


    # TODO: implement your 2d convolution
    output = 

    return output