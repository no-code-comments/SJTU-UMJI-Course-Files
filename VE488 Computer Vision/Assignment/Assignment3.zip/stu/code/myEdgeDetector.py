from contextlib import suppress
from typing import Tuple, Union 

import matplotlib.pyplot as plt
import numpy as np

from myConvolution  import myConv2D


def GaussianKernel(sigma:float=1.):
    """Generate a gaussian kernel with the given standard deviation.

    The kernel size is decided by 2*ceil(3*sigma) + 1
    """
    # TODO: calculate the kernel size and initialize

    # TODO:  generate the gaussian kernel
    kernel = 

    return kernel


def SobelFilter(img:np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    # the Sobel operators on x-direction and y-direction
    Kx = np.array([[-1,0,1], [-2,0,2], [-1,0,1]], np.float32)
    Ky = np.array([[1,2,1], [0,0,0], [-1,-2,-1]], np.float32)

    # TODO: calculate the intensity gradient
    Gx = 
    Gy = 
    G = 
    theta = 

    return G, theta


def NMS(img:np.ndarray, angles:np.ndarray) -> np.ndarray:
    """Process the image with non-max suppression algorithm
    """
    # map the gradient angle to the closest of 4 cases, where the line is sloped at 
    #   almost 0 degree, 45 degree, 90 degree, and 135 degree

    suppressed = 
    return suppressed


def myCanny(
    img:np.ndarray, 
    sigma:Union[float, Tuple[float,float]]=1.,
    threshold:Tuple[int,int]=(100,150)) -> np.ndarray:
    """Apply Canny algorithm to detect the edge in an image.

    Returns: The edge detection result whose size is the same as the input image.
    """
    # denoise the image by a convolution with the gaussian filter
    #   TODO: implement the Gaussian kernel generator
    gaussian_kernel = GaussianKernel(sigma)
    padding = np.floor(np.array(gaussian_kernel.shape)/2)
    denoised = myConv2D(img, gaussian_kernel, padding=(int(padding[0]), int(padding[1])))
    plt.imsave("./zebra_denoised.jpg", denoised, cmap="Greys_r")

    # find the intensity gradient of the image
    #   TODO: implement the Sobel filter
    gradient, angles = SobelFilter(denoised)
    plt.imsave("./zebra_gradient.jpg", gradient, cmap="Greys_r")

    # find the edge candidates by non-max suppression
    #   TODO: implement the non-max suppression function
    nms = NMS(gradient, angles)
    plt.imsave("./zebra_nms.jpg", nms, cmap="Greys_r")

    # TODO: determine the potential edges by the hysteresis threshold

    output = 
    plt.imsave("./zebra_edge.jpg", output, cmap="Greys_r")
    return output