import numpy as np  
import struct  
import matplotlib.pyplot as plt  
import operator

# Read the image data
filename = 't10k-images-idx3-ubyte'  
binfile = open(filename , 'rb')  
buf = binfile.read()  
index = 0  
magic, numImages , numRows , numColumns = struct.unpack_from('>IIII' , buf , index)  
index += struct.calcsize('>IIII')  

# Read the labels
filename1 =  't10k-labels-idx1-ubyte'  
binfile1 = open(filename1 , 'rb')  
buf1 = binfile1.read()  
  
index1 = 0  
magic1, numLabels1 = struct.unpack_from('>II' , buf , index)  
index1 += struct.calcsize('>II')  

# Initialization
DataNumbers = 10000
datamat = np.zeros((DataNumbers,28*28))
datalabel = []

# Collect data
for i in range(DataNumbers):
    im = struct.unpack_from('>784B' ,buf, index)  
    index += struct.calcsize('>784B')  
    im = np.array(im) 
    datamat[i]=im
    numtemp = struct.unpack_from('1B' ,buf1, index1) 
    label = numtemp[0]
    index1 += struct.calcsize('1B')
    datalabel.append(label)

### Start your PCA ###


