import numpy as np
from numpy.linalg import eig
import matplotlib.pyplot as plt

def pca_basic():
    ### Data
    c1 = np.array([[2,2,2],[1,2,3]])
    c2 = np.array([[4,5,6],[3,3,4]])
    c = np.concatenate((c1,c2),axis=1)

    ### Calculate w and w0 here


    print('w is:', w)
    print('w0 is:', w0)
    ### Plot the reconstructed points here



    ### Calculate MSE here


    print('MSE is:', MSE)
    ### Calculate the Fisher Ratio here


    print('Fisher Ratio is:', FR)
    return w,w0,MSE,FR


pca_basic()


