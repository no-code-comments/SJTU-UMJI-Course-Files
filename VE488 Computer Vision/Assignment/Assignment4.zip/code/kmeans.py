import numpy as np
import matplotlib.pyplot as plt

data = np.load('kmeans_array1.npy')

# Visualize data
plt.plot(data[:, 0], data[:, 1], c='c',s=30,marker='o')
plt.show()

### Start your K-means ###


