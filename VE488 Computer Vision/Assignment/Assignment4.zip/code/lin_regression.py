import numpy as np

# Template code for gradient descent, to make the implementation
# a bit more straightforward.
# Please fill in the missing pieces, and then feel free to
# call it as needed in the functions below.
def gradient_descent(X, y, lr, num_iters):
    losses = []
    n, d = X.shape
    w = np.zeros((d,1))
    for i in range(num_iters):
        grad = ##### ADD YOUR CODE HERE
        w = w - lr * grad
        loss = ##### ADD YOUR CODE HERE: f(w) = ...? (with lambda = 0)
        losses.append(loss)
    return losses, w

# Code for (2-5)
def linear_regression():
    X = np.array([[1,1],[2,3],[3,3]])
    Y = np.array([[1],[3],[3]])    

    ##### ADD YOUR CODE FOR ALL PARTS HERE



